package com.example.unscript_rookies_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
